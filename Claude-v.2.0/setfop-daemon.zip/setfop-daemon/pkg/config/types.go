package config

// WatchPath represents a single monitored path entry.
type WatchPath struct {
	Path      string
	Recursive bool
}

// AlertConfig holds alert output settings.
type AlertConfig struct {
	LogFile        string
	LogLevel       string
	SyslogEnable   bool
	SyslogFacility string
	SyslogTag      string
	EmailEnable    bool
	EmailTo        string
	EmailSMTP      string
	WebhookEnable  bool
	WebhookURL     string
	WebhookToken   string
}

// Config is the top-level runtime configuration for setfopd.
type Config struct {
	// From paths.conf
	WatchPaths []WatchPath

	// From setfop.conf
	BaselinePath      string
	ScanInterval      int // seconds
	CollectSelinux    bool
	SeverityRulesPath string

	// Alert settings
	Alert AlertConfig
}
