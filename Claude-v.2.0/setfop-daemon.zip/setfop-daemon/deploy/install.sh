#!/usr/bin/env bash
# SETFOP install script
# Must be run as root.
set -euo pipefail

BINARY_SRC="$(dirname "$0")/../setfopd"   # built binary expected here
BINARY_DST="/opt/setfop/bin/setfopd"
CONF_DIR="/etc/setfop"
DATA_DIR="/var/lib/setfop/templates"
LOG_DIR="/var/log/setfop"
SERVICE_FILE="/usr/lib/systemd/system/setfopd.service"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

info()    { echo -e "${GREEN}[+]${NC} $*"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*"; }
error()   { echo -e "${RED}[✗]${NC} $*"; exit 1; }

# ── Preflight checks ──────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && error "This script must be run as root."

command -v go &>/dev/null || error "Go toolchain not found. Install Go 1.22+ first."

info "SETFOP Installer"
echo "  Project: $PROJECT_DIR"
echo "  Binary : $BINARY_DST"
echo "  Config : $CONF_DIR"
echo ""

# ── Build binary ──────────────────────────────────────────────────────────────
info "Building setfopd..."
cd "$PROJECT_DIR"
go mod tidy
go build -o "$PROJECT_DIR/setfopd" ./cmd/setfopd/
info "Build successful."

# ── Create directory layout ───────────────────────────────────────────────────
info "Creating directories..."
install -d -m 0755 "$(dirname "$BINARY_DST")"
install -d -m 0750 "$CONF_DIR"
install -d -m 0750 "$DATA_DIR"
install -d -m 0750 "$LOG_DIR"

# ── Install binary ────────────────────────────────────────────────────────────
info "Installing binary to $BINARY_DST..."
install -m 0750 "$PROJECT_DIR/setfopd" "$BINARY_DST"

# ── Install config files (do not overwrite existing) ─────────────────────────
info "Installing config files..."
for f in setfop.conf paths.conf severity.rules; do
    src="$PROJECT_DIR/configs/$f"
    dst="$CONF_DIR/$f"
    if [[ -f "$dst" ]]; then
        warn "$dst already exists — skipping (use --force to overwrite)"
    else
        install -m 0640 "$src" "$dst"
        info "  Installed $dst"
    fi
done

# ── Install systemd service ───────────────────────────────────────────────────
info "Installing systemd service..."
install -m 0644 "$SCRIPT_DIR/setfopd.service" "$SERVICE_FILE"
systemctl daemon-reload
info "  Service file installed at $SERVICE_FILE"

# ── Generate initial baseline ─────────────────────────────────────────────────
read -rp "[?] Generate initial baseline now? (recommended) [Y/n]: " yn
yn="${yn:-Y}"
if [[ "$yn" =~ ^[Yy]$ ]]; then
    info "Generating baseline (this may take a minute)..."
    "$BINARY_DST" --generate-baseline \
        --config="$CONF_DIR/setfop.conf" \
        --paths-config="$CONF_DIR/paths.conf"
    info "Baseline written to $DATA_DIR/baseline.yaml"
fi

# ── Enable and start service ──────────────────────────────────────────────────
read -rp "[?] Enable and start setfopd service now? [Y/n]: " yn2
yn2="${yn2:-Y}"
if [[ "$yn2" =~ ^[Yy]$ ]]; then
    systemctl enable setfopd
    systemctl start  setfopd
    sleep 1
    systemctl status setfopd --no-pager
    info "setfopd is running."
else
    echo ""
    echo "To start manually later:"
    echo "  systemctl enable --now setfopd"
fi

echo ""
info "Installation complete!"
echo ""
echo "Useful commands:"
echo "  systemctl status setfopd          — check daemon status"
echo "  systemctl reload setfopd          — reload baseline (SIGHUP)"
echo "  setfopd --scan --compare          — one-shot manual scan"
echo "  setfopd --generate-baseline       — re-snapshot the filesystem"
echo "  tail -f $LOG_DIR/drift.log        — watch live alerts"
