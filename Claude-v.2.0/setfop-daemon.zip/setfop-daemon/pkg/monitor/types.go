package monitor

// Event wraps an inotify filesystem event before processing.
type Event struct {
	Path      string
	Operation string // CREATE, MODIFY, DELETE, CHMOD
}
