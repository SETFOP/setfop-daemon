package util

import (
	"fmt"
	"os"
)

// FormatMode returns a 4-digit octal string for the file's permission bits.
func FormatMode(mode os.FileMode) string {
	return fmt.Sprintf("%04o", mode.Perm())
}

// IsSetUID reports whether a file has the setuid bit set.
func IsSetUID(mode os.FileMode) bool {
	return mode&os.ModeSetuid != 0
}

// IsSetGID reports whether a file has the setgid bit set.
func IsSetGID(mode os.FileMode) bool {
	return mode&os.ModeSetgid != 0
}
