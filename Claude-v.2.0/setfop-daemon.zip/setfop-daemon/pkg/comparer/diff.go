package comparer

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/sys/unix"

	"setfop-daemon/pkg/baseline"
	"setfop-daemon/pkg/config"
	"setfop-daemon/pkg/util"
)

// Comparer holds state needed to perform a diff.
type Comparer struct {
	rules *RuleSet
	cfg   *config.Config
}

// New creates a Comparer with loaded rules.
func New(cfg *config.Config) (*Comparer, error) {
	rules, err := LoadRules(cfg.SeverityRulesPath)
	if err != nil {
		return nil, err
	}
	return &Comparer{rules: rules, cfg: cfg}, nil
}

// DiffBaseline loads the saved baseline and compares it against the live filesystem.
// Returns all detected changes.
func (c *Comparer) DiffBaseline() ([]Change, error) {
	bl, err := baseline.Load(c.cfg.BaselinePath)
	if err != nil {
		return nil, fmt.Errorf("cannot load baseline: %w", err)
	}

	// Scan current state for every path in the baseline
	current, err := c.scanCurrentState(bl)
	if err != nil {
		return nil, err
	}

	return c.compare(bl, current), nil
}

// DiffPath compares a single path against the baseline (used by inotify).
func (c *Comparer) DiffPath(path string, bl *baseline.Baseline) []Change {
	baselineMap := indexBaseline(bl)

	info, err := os.Stat(path)
	if err != nil {
		// File deleted
		if entry, exists := baselineMap[path]; exists {
			sev, rule := c.rules.Classify(path)
			return []Change{{
				Path:     path,
				Type:     ChangeDeleted,
				Old:      &entry,
				Severity: sev,
				RuleName: rule,
			}}
		}
		return nil
	}

	entry := collectMeta(path, info)
	if baselineEntry, exists := baselineMap[path]; exists {
		return c.diffEntries(baselineEntry, entry)
	}

	// New file
	sev, rule := c.rules.Classify(path)
	return []Change{{
		Path:     path,
		Type:     ChangeAdded,
		New:      &entry,
		Severity: sev,
		RuleName: rule,
	}}
}

// scanCurrentState walks all paths referenced in the baseline.
func (c *Comparer) scanCurrentState(bl *baseline.Baseline) ([]baseline.FileEntry, error) {
	visited := make(map[string]bool)
	var entries []baseline.FileEntry

	for _, e := range bl.Entries {
		dir := filepath.Dir(e.Path)
		if !visited[dir] {
			visited[dir] = true
			// Walk the directory to catch new files too
			filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
				if err != nil {
					return nil
				}
				entries = append(entries, collectMeta(path, info))
				return nil
			})
		}
	}

	return entries, nil
}

// compare performs the full diff between a baseline and a current scan.
func (c *Comparer) compare(bl *baseline.Baseline, current []baseline.FileEntry) []Change {
	var changes []Change

	baselineMap := indexBaseline(bl)
	currentMap := make(map[string]baseline.FileEntry)
	for _, e := range current {
		currentMap[e.Path] = e
	}

	// Detect modifications and additions
	for _, cur := range current {
		if base, exists := baselineMap[cur.Path]; exists {
			diffs := c.diffEntries(base, cur)
			changes = append(changes, diffs...)
		} else {
			sev, rule := c.rules.Classify(cur.Path)
			if sev == "IGNORE" {
				continue
			}
			changes = append(changes, Change{
				Path:     cur.Path,
				Type:     ChangeAdded,
				New:      ptr(cur),
				Severity: sev,
				RuleName: rule,
			})
		}
	}

	// Detect deletions
	for path, base := range baselineMap {
		if _, exists := currentMap[path]; !exists {
			sev, rule := c.rules.Classify(path)
			if sev == "IGNORE" {
				continue
			}
			changes = append(changes, Change{
				Path:     path,
				Type:     ChangeDeleted,
				Old:      ptr(base),
				Severity: sev,
				RuleName: rule,
			})
		}
	}

	return changes
}

// diffEntries compares two FileEntry structs field-by-field.
func (c *Comparer) diffEntries(base, cur baseline.FileEntry) []Change {
	var fields []string

	if base.Inode != cur.Inode {
		fields = append(fields, "inode")
	}
	if base.Mode != cur.Mode {
		fields = append(fields, "mode")
	}
	if base.UID != cur.UID {
		fields = append(fields, "uid")
	}
	if base.GID != cur.GID {
		fields = append(fields, "gid")
	}
	if base.Size != cur.Size {
		fields = append(fields, "size")
	}
	if base.ModTime != cur.ModTime {
		fields = append(fields, "mod_time")
	}
	if base.SelinuxCtx != cur.SelinuxCtx {
		fields = append(fields, "selinux_context")
	}

	if len(fields) == 0 {
		return nil
	}

	sev, rule := c.rules.Classify(cur.Path)
	if sev == "IGNORE" {
		return nil
	}

	return []Change{{
		Path:       cur.Path,
		Type:       ChangeModified,
		Old:        ptr(base),
		New:        ptr(cur),
		DiffFields: fields,
		Severity:   sev,
		RuleName:   rule,
	}}
}

// collectMeta gathers live metadata for a single path.
func collectMeta(path string, info os.FileInfo) baseline.FileEntry {
	var stat unix.Stat_t
	unix.Stat(path, &stat)

	return baseline.FileEntry{
		Path:       path,
		Inode:      stat.Ino,
		Mode:       fmt.Sprintf("%04o", info.Mode().Perm()),
		UID:        int(stat.Uid),
		GID:        int(stat.Gid),
		SelinuxCtx: util.GetSelinuxContext(path),
		Size:       info.Size(),
		ModTime:    info.ModTime().Format(time.RFC3339),
	}
}

// indexBaseline builds a map[path]FileEntry for O(1) lookups.
func indexBaseline(bl *baseline.Baseline) map[string]baseline.FileEntry {
	m := make(map[string]baseline.FileEntry, len(bl.Entries))
	for _, e := range bl.Entries {
		m[e.Path] = e
	}
	return m
}

func ptr(e baseline.FileEntry) *baseline.FileEntry { return &e }

// Scan re-scans paths and writes a fresh baseline snapshot to a temp YAML for
// ad-hoc use by the --scan CLI flag.
func Scan(cfg *config.Config) ([]baseline.FileEntry, error) {
	bl, err := baseline.Load(cfg.BaselinePath)
	if err != nil {
		return nil, err
	}

	var entries []baseline.FileEntry
	for _, e := range bl.Entries {
		info, err := os.Stat(e.Path)
		if err != nil {
			continue
		}
		entries = append(entries, collectMeta(e.Path, info))
	}
	return entries, nil
}
