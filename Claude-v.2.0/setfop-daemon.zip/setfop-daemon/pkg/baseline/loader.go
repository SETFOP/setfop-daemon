package baseline

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// Load reads a baseline YAML file from disk and returns the parsed Baseline.
func Load(path string) (*Baseline, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("failed to read baseline file %s: %w", path, err)
	}

	var bl Baseline
	if err := yaml.Unmarshal(data, &bl); err != nil {
		return nil, fmt.Errorf("failed to parse baseline YAML: %w", err)
	}

	if len(bl.Entries) == 0 {
		return nil, fmt.Errorf("baseline file is empty or has no entries: %s", path)
	}

	return &bl, nil
}
