package baseline

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/sys/unix"
	"gopkg.in/yaml.v3"

	"setfop-daemon/pkg/config"
	"setfop-daemon/pkg/util"
)

const (
	defaultOutputPath = "/var/lib/setfop/templates/baseline.yaml"
	baselineVersion   = "1.0"
)

// Generate scans all paths defined in the config and writes a baseline YAML file.
func Generate(cfg *config.Config) error {
	fmt.Println("Starting baseline generation...")

	var entries []FileEntry

	for _, wp := range cfg.WatchPaths {
		fmt.Printf("Scanning: %s (recursive=%v)\n", wp.Path, wp.Recursive)

		if _, err := os.Stat(wp.Path); os.IsNotExist(err) {
			fmt.Printf("Warning: path does not exist, skipping: %s\n", wp.Path)
			continue
		}

		if wp.Recursive {
			err := filepath.Walk(wp.Path, func(path string, info os.FileInfo, err error) error {
				if err != nil {
					fmt.Printf("Warning: cannot access %s: %v\n", path, err)
					return nil
				}
				entry := collectMetadata(path, info)
				entries = append(entries, entry)
				return nil
			})
			if err != nil {
				fmt.Printf("Warning: walk error on %s: %v\n", wp.Path, err)
			}
		} else {
			info, err := os.Stat(wp.Path)
			if err != nil {
				fmt.Printf("Warning: cannot stat %s: %v\n", wp.Path, err)
				continue
			}
			entry := collectMetadata(wp.Path, info)
			entries = append(entries, entry)
		}
	}

	hostname, _ := os.Hostname()
	bl := Baseline{
		Version:     baselineVersion,
		GeneratedAt: time.Now().Format(time.RFC3339),
		Hostname:    hostname,
		Entries:     entries,
	}

	data, err := yaml.Marshal(&bl)
	if err != nil {
		return fmt.Errorf("failed to marshal baseline: %w", err)
	}

	outputPath := cfg.BaselinePath
	if outputPath == "" {
		outputPath = defaultOutputPath
	}

	// Ensure the output directory exists
	if err := os.MkdirAll(filepath.Dir(outputPath), 0750); err != nil {
		return fmt.Errorf("failed to create output directory: %w", err)
	}

	if err := os.WriteFile(outputPath, data, 0600); err != nil {
		return fmt.Errorf("failed to write baseline file: %w", err)
	}

	fmt.Printf("Baseline written to %s (%d entries)\n", outputPath, len(entries))
	return nil
}

// collectMetadata gathers all monitored attributes for a single path.
func collectMetadata(path string, info os.FileInfo) FileEntry {
	var stat unix.Stat_t
	if err := unix.Stat(path, &stat); err != nil {
		fmt.Printf("Warning: could not stat %s: %v\n", path, err)
	}

	return FileEntry{
		Path:       path,
		Inode:      stat.Ino,
		Mode:       fmt.Sprintf("%04o", info.Mode().Perm()),
		UID:        int(stat.Uid),
		GID:        int(stat.Gid),
		SelinuxCtx: util.GetSelinuxContext(path),
		Size:       info.Size(),
		ModTime:    info.ModTime().Format(time.RFC3339),
	}
}
