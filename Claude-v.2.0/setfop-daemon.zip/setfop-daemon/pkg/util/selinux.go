package util

import (
	"strings"

	"golang.org/x/sys/unix"
)

// GetSelinuxContext returns the SELinux security context for a file path.
// Returns an empty string on non-SELinux systems or if the attribute is not set.
func GetSelinuxContext(path string) string {
	b := make([]byte, 512)
	n, err := unix.Getxattr(path, "security.selinux", b)
	if err != nil {
		return ""
	}
	// Trim trailing null byte that SELinux appends
	return strings.TrimRight(string(b[:n]), "\x00")
}
