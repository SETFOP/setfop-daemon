#!/usr/bin/env bash
# SETFOP uninstall script
set -euo pipefail

[[ $EUID -ne 0 ]] && { echo "Must be run as root."; exit 1; }

echo "[!] This will stop and remove setfopd from this system."
read -rp "Are you sure? [y/N]: " yn
[[ "$yn" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }

# Stop and disable service
if systemctl is-active --quiet setfopd 2>/dev/null; then
    systemctl stop setfopd
    echo "[+] Service stopped."
fi
if systemctl is-enabled --quiet setfopd 2>/dev/null; then
    systemctl disable setfopd
    echo "[+] Service disabled."
fi

# Remove files
FILES=(
    /usr/lib/systemd/system/setfopd.service
    /opt/setfop/bin/setfopd
)
for f in "${FILES[@]}"; do
    [[ -f "$f" ]] && rm -f "$f" && echo "[+] Removed $f"
done

systemctl daemon-reload

echo ""
echo "Note: config files in /etc/setfop/ and data in /var/lib/setfop/"
echo "were NOT removed. Delete them manually if desired:"
echo "  rm -rf /etc/setfop /var/lib/setfop /var/log/setfop"
echo ""
echo "[+] Uninstall complete."
