module setfop-daemon

go 1.22

require (
	github.com/fsnotify/fsnotify v1.7.0
	golang.org/x/sys v0.18.0
	gopkg.in/yaml.v3 v3.0.1
)
