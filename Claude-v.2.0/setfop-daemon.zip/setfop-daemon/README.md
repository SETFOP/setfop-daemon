# SETFOP — File Integrity Monitor

SETFOP is a lightweight Linux file integrity monitoring daemon written in Go.
It snapshots filesystem metadata into a baseline, then watches for deviations
using inotify (real-time) and periodic full scans (fallback), alerting on any
change to permissions, ownership, size, inode, modification time, or SELinux context.

---

## Features

- **Real-time monitoring** via Linux inotify with 2-second debounce
- **Periodic fallback scan** (default: every 15 minutes) to catch changes missed by inotify
- **Structured alert log** at `/var/log/setfop/drift.log`
- **Severity classification** via configurable `severity.rules`
- **SELinux context tracking** (via `security.selinux` xattr, optional)
- **Graceful reload** on `SIGHUP` — reloads baseline without restart
- **systemd integration** with hardened unit file
- **IGNORE rules** to suppress noisy paths (tmp, proc, cache, etc.)

---

## Project Layout

```
setfop-daemon/
├── cmd/setfopd/main.go          # CLI entry point, mode dispatch
├── pkg/
│   ├── baseline/                # Baseline generation and loading
│   ├── comparer/                # Diff engine + severity rules
│   ├── monitor/                 # inotify daemon loop
│   ├── alert/                   # Structured logging + syslog
│   ├── config/                  # Config file parsing
│   └── util/                    # SELinux + permission helpers
├── configs/
│   ├── setfop.conf              # Main daemon config
│   ├── paths.conf               # Monitored paths
│   └── severity.rules           # Change severity classification
└── deploy/
    ├── setfopd.service          # systemd unit
    ├── install.sh               # Automated installer
    └── uninstall.sh             # Cleanup
```

---

## Quick Start

### 1. Install

```bash
cd setfop-daemon
sudo bash deploy/install.sh
```

The installer will:
- Build the binary with `go build`
- Install it to `/opt/setfop/bin/setfopd`
- Copy config files to `/etc/setfop/`
- Optionally generate the initial baseline
- Optionally enable and start the systemd service

### 2. Manual setup (if not using the installer)

```bash
# Build
go mod tidy
go build -o setfopd ./cmd/setfopd/

# Create directories
sudo install -d /opt/setfop/bin /etc/setfop /var/lib/setfop/templates /var/log/setfop

# Install binary and configs
sudo install -m 0750 setfopd /opt/setfop/bin/setfopd
sudo cp configs/* /etc/setfop/

# Generate baseline
sudo /opt/setfop/bin/setfopd --generate-baseline

# Start daemon
sudo systemctl enable --now setfopd
```

---

## CLI Reference

```
setfopd [--config=PATH] [--paths-config=PATH] <mode>

Modes:
  --generate-baseline     Scan filesystem and write baseline.yaml
  --daemon                Start inotify daemon (used by systemd)
  --scan --compare        One-shot manual scan and diff
  --compare               Diff live filesystem against saved baseline
  --validate-config       Print parsed config and exit

Options:
  --config=PATH           Default: /etc/setfop/setfop.conf
  --paths-config=PATH     Default: /etc/setfop/paths.conf
```

---

## Configuration

### `/etc/setfop/setfop.conf`

| Section    | Key               | Default                                    | Description                        |
|------------|-------------------|--------------------------------------------|-----------------------------------|
| baseline   | baseline_path     | /var/lib/setfop/templates/baseline.yaml    | Where to read/write baseline      |
| baseline   | collect_selinux   | true                                       | Collect SELinux xattr             |
| baseline   | severity_rules    | /etc/setfop/severity.rules                 | Path to rules file                |
| monitor    | scan_interval     | 900                                        | Periodic scan interval (seconds)  |
| alerts     | log_file          | /var/log/setfop/drift.log                  | Alert log path                    |
| alerts     | log_level         | INFO                                       | Minimum severity to log           |
| alerts     | syslog_enable     | false                                      | Send alerts to syslog             |

### `/etc/setfop/paths.conf`

```
/etc/passwd           # watch single file
/bin/*                # watch directory recursively
```

### `/etc/setfop/severity.rules`

```
/etc/shadow    CRITICAL "Password database modified"
/usr/bin/*     HIGH     "System binary changed"
/var/log/*     LOW      "Log rotated"
/tmp/*         IGNORE   "Suppress noisy temp files"
```

---

## Alert Log Format

```
2026-03-27T10:15:23Z [HIGH] MODIFIED: /usr/bin/passwd
  - mode: 0755 -> 0777
  - mod_time: 2026-03-26T08:00:00Z -> 2026-03-27T10:15:20Z
  Rule matched: "/usr/bin/*" -> severity=HIGH
```

---

## Systemd Commands

```bash
systemctl status setfopd          # Check daemon status
systemctl reload setfopd          # Reload baseline (sends SIGHUP)
systemctl restart setfopd         # Full restart
journalctl -u setfopd -f          # Follow daemon logs
tail -f /var/log/setfop/drift.log # Follow alert log
```

---

## Re-baselining After Legitimate Changes

After a system update or intentional config change, regenerate the baseline:

```bash
sudo /opt/setfop/bin/setfopd --generate-baseline
sudo systemctl reload setfopd
```

---

## Dependencies

| Package                       | Purpose                        |
|-------------------------------|--------------------------------|
| `github.com/fsnotify/fsnotify`| inotify wrapper                |
| `golang.org/x/sys`            | Getxattr, Stat_t syscalls      |
| `gopkg.in/yaml.v3`            | YAML baseline serialisation    |
