package alert

// Severity ordering for filtering.
var severityOrder = map[string]int{
	"IGNORE":   0,
	"LOW":      1,
	"MEDIUM":   2,
	"HIGH":     3,
	"CRITICAL": 4,
}

// SeverityAtLeast returns true if sev is >= minLevel.
func SeverityAtLeast(sev, minLevel string) bool {
	return severityOrder[sev] >= severityOrder[minLevel]
}
