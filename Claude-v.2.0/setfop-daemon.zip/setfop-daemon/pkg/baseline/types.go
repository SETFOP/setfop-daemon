package baseline

// FileEntry holds the captured metadata for a single file or directory.
type FileEntry struct {
	Path       string `yaml:"path"`
	Inode      uint64 `yaml:"inode"`
	Mode       string `yaml:"mode"`
	UID        int    `yaml:"uid"`
	GID        int    `yaml:"gid"`
	SelinuxCtx string `yaml:"selinux_context"`
	Size       int64  `yaml:"size"`
	ModTime    string `yaml:"mod_time"`
}

// Baseline is the top-level structure written to baseline.yaml.
type Baseline struct {
	Version     string      `yaml:"version"`
	GeneratedAt string      `yaml:"generated_at"`
	Hostname    string      `yaml:"hostname"`
	Entries     []FileEntry `yaml:"entries"`
}
