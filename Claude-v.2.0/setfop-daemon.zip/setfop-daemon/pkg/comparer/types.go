package comparer

import "setfop-daemon/pkg/baseline"

// ChangeType categorises what happened to a file.
type ChangeType string

const (
	ChangeAdded    ChangeType = "added"
	ChangeDeleted  ChangeType = "deleted"
	ChangeModified ChangeType = "modified"
)

// Change describes a single detected difference between baseline and current state.
type Change struct {
	Path       string              `json:"path"`
	Type       ChangeType          `json:"type"`
	Old        *baseline.FileEntry `json:"old,omitempty"`
	New        *baseline.FileEntry `json:"new,omitempty"`
	DiffFields []string            `json:"changed_fields,omitempty"`
	Severity   string              `json:"severity"`
	RuleName   string              `json:"rule_name,omitempty"`
}
