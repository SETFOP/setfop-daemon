package comparer

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Rule maps a path pattern to a severity level.
type Rule struct {
	Pattern     string
	Severity    string
	Description string
}

// RuleSet is the loaded set of severity rules.
type RuleSet struct {
	rules []Rule
}

// LoadRules parses the severity.rules file.
// Format per line: <pattern> <SEVERITY> "<description>"
func LoadRules(path string) (*RuleSet, error) {
	f, err := os.Open(path)
	if err != nil {
		// Non-fatal: return an empty rule set that will default to MEDIUM
		fmt.Printf("Warning: could not load severity rules from %s: %v\n", path, err)
		return &RuleSet{}, nil
	}
	defer f.Close()

	var rules []Rule
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		// Format: /path/pattern SEVERITY "description"
		// Split on whitespace, max 3 parts
		parts := strings.SplitN(line, " ", 3)
		if len(parts) < 2 {
			continue
		}

		desc := ""
		if len(parts) == 3 {
			desc = strings.Trim(parts[2], `"`)
		}

		rules = append(rules, Rule{
			Pattern:     parts[0],
			Severity:    strings.ToUpper(parts[1]),
			Description: desc,
		})
	}

	return &RuleSet{rules: rules}, scanner.Err()
}

// Classify returns the severity level for a given file path.
// Rules are evaluated in order; first match wins.
// Returns "MEDIUM" if no rule matches.
func (rs *RuleSet) Classify(path string) (severity, ruleName string) {
	for _, r := range rs.rules {
		if r.Severity == "IGNORE" {
			matched, _ := filepath.Match(r.Pattern, path)
			if matched {
				return "IGNORE", r.Pattern
			}
		}

		matched, err := filepath.Match(r.Pattern, path)
		if err != nil {
			continue
		}
		if matched {
			return r.Severity, r.Pattern
		}

		// Also match if the path is under a wildcard directory pattern
		if strings.HasSuffix(r.Pattern, "/*") {
			dir := strings.TrimSuffix(r.Pattern, "/*")
			if strings.HasPrefix(path, dir+"/") {
				return r.Severity, r.Pattern
			}
		}
	}

	return "MEDIUM", "" // default
}
