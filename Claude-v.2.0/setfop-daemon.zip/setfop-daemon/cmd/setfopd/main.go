package main

import (
	"fmt"
	"os"

	"setfop-daemon/pkg/alert"
	"setfop-daemon/pkg/baseline"
	"setfop-daemon/pkg/comparer"
	"setfop-daemon/pkg/config"
	"setfop-daemon/pkg/monitor"
)

const (
	defaultConfPath      = "/etc/setfop/setfop.conf"
	defaultPathsConfPath = "/etc/setfop/paths.conf"
)

func main() {
	args := os.Args[1:]

	if hasFlag(args, "--help") || hasFlag(args, "-h") {
		printHelp()
		return
	}

	confPath := flagValue(args, "--config", defaultConfPath)
	pathsConf := flagValue(args, "--paths-config", defaultPathsConfPath)

	cfg, err := config.Load(confPath, pathsConf)
	if err != nil {
		fatalf("Failed to load configuration: %v\n", err)
	}

	switch {

	case hasFlag(args, "--generate-baseline"):
		// Scan filesystem and write a new baseline.yaml
		if err := baseline.Generate(cfg); err != nil {
			fatalf("Baseline generation failed: %v\n", err)
		}

	case hasFlag(args, "--scan") && hasFlag(args, "--compare"):
		// One-shot: scan current state and diff against baseline
		runScanAndCompare(cfg)

	case hasFlag(args, "--scan"):
		// Just print what's currently on disk (no diff)
		entries, err := comparer.Scan(cfg)
		if err != nil {
			fatalf("Scan failed: %v\n", err)
		}
		fmt.Printf("Scanned %d files.\n", len(entries))

	case hasFlag(args, "--compare"):
		// Diff without re-scanning (uses cached baseline paths)
		runScanAndCompare(cfg)

	case hasFlag(args, "--daemon"):
		// Full daemon mode: inotify + periodic scan
		m, err := monitor.New(cfg)
		if err != nil {
			fatalf("Failed to start daemon: %v\n", err)
		}
		if err := m.Start(); err != nil {
			fatalf("Daemon exited with error: %v\n", err)
		}

	case hasFlag(args, "--validate-config"):
		fmt.Printf("Configuration loaded successfully.\n")
		fmt.Printf("  Baseline path : %s\n", cfg.BaselinePath)
		fmt.Printf("  Severity rules: %s\n", cfg.SeverityRulesPath)
		fmt.Printf("  Scan interval : %ds\n", cfg.ScanInterval)
		fmt.Printf("  Alert log     : %s\n", cfg.Alert.LogFile)
		fmt.Printf("  Watch paths   : %d configured\n", len(cfg.WatchPaths))
		for _, wp := range cfg.WatchPaths {
			rec := ""
			if wp.Recursive {
				rec = " (recursive)"
			}
			fmt.Printf("    %s%s\n", wp.Path, rec)
		}

	default:
		printHelp()
		os.Exit(1)
	}
}

// runScanAndCompare diffs the live filesystem against the saved baseline
// and logs any detected changes.
func runScanAndCompare(cfg *config.Config) {
	comp, err := comparer.New(cfg)
	if err != nil {
		fatalf("Failed to initialise comparer: %v\n", err)
	}

	changes, err := comp.DiffBaseline()
	if err != nil {
		fatalf("Comparison failed: %v\n", err)
	}

	if len(changes) == 0 {
		fmt.Println("No changes detected.")
		return
	}

	fmt.Printf("Detected %d change(s):\n\n", len(changes))

	logger, err := alert.NewLogger(cfg.Alert)
	if err != nil {
		fatalf("Failed to open alert logger: %v\n", err)
	}
	defer logger.Close()

	logger.LogChanges(changes)
}

// hasFlag checks if a flag string appears in the argument list.
func hasFlag(args []string, flag string) bool {
	for _, a := range args {
		if a == flag {
			return true
		}
	}
	return false
}

// flagValue returns the value of --flag=value or the default.
func flagValue(args []string, flag, def string) string {
	prefix := flag + "="
	for _, a := range args {
		if len(a) > len(prefix) && a[:len(prefix)] == prefix {
			return a[len(prefix):]
		}
	}
	return def
}

func fatalf(format string, args ...interface{}) {
	fmt.Fprintf(os.Stderr, "setfopd: "+format, args...)
	os.Exit(1)
}

func printHelp() {
	fmt.Print(`setfopd - File Integrity Monitor

Usage:
  setfopd [--config=PATH] [--paths-config=PATH] <mode>

Modes:
  --generate-baseline     Scan filesystem and write a new baseline snapshot
  --daemon                Start real-time inotify monitoring daemon
  --scan --compare        One-shot: scan + diff against baseline
  --compare               Diff current filesystem against saved baseline
  --validate-config       Print loaded configuration and exit

Options:
  --config=PATH           Path to setfop.conf  (default: /etc/setfop/setfop.conf)
  --paths-config=PATH     Path to paths.conf   (default: /etc/setfop/paths.conf)
  --help, -h              Show this help

Examples:
  setfopd --generate-baseline
  setfopd --daemon
  setfopd --scan --compare
  setfopd --validate-config
`)
}
