package monitor

import (
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"github.com/fsnotify/fsnotify"

	"setfop-daemon/pkg/alert"
	"setfop-daemon/pkg/baseline"
	"setfop-daemon/pkg/comparer"
	"setfop-daemon/pkg/config"
)

// Monitor is the daemon-mode watcher. It combines inotify (real-time) with
// periodic full-scan fallback to ensure no changes are missed.
type Monitor struct {
	cfg      *config.Config
	watcher  *fsnotify.Watcher
	comp     *comparer.Comparer
	logger   *alert.Logger
	baseline *baseline.Baseline

	// Debounce: path → pending timer
	debounceMu sync.Mutex
	debounce   map[string]*time.Timer

	stopCh chan struct{}
}

// New creates and initialises a Monitor.
func New(cfg *config.Config) (*Monitor, error) {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		return nil, fmt.Errorf("failed to create inotify watcher: %w", err)
	}

	comp, err := comparer.New(cfg)
	if err != nil {
		return nil, fmt.Errorf("failed to create comparer: %w", err)
	}

	logger, err := alert.NewLogger(cfg.Alert)
	if err != nil {
		return nil, fmt.Errorf("failed to create alert logger: %w", err)
	}

	bl, err := baseline.Load(cfg.BaselinePath)
	if err != nil {
		return nil, fmt.Errorf("failed to load baseline: %w", err)
	}

	return &Monitor{
		cfg:      cfg,
		watcher:  watcher,
		comp:     comp,
		logger:   logger,
		baseline: bl,
		debounce: make(map[string]*time.Timer),
		stopCh:   make(chan struct{}),
	}, nil
}

// Start registers all configured watch paths and enters the event loop.
// It blocks until SIGINT/SIGTERM is received or Stop() is called.
func (m *Monitor) Start() error {
	defer m.watcher.Close()
	defer m.logger.Close()

	// Register all watch paths
	if err := m.registerPaths(); err != nil {
		return err
	}

	fmt.Printf("[setfopd] Daemon started. Watching %d path(s). Periodic scan every %ds.\n",
		len(m.cfg.WatchPaths), m.cfg.ScanInterval)

	// Handle SIGHUP for config reload and SIGINT/SIGTERM for clean shutdown
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP)

	// Periodic full-scan ticker (fallback for network mounts, inotify limits, etc.)
	ticker := time.NewTicker(time.Duration(m.cfg.ScanInterval) * time.Second)
	defer ticker.Stop()

	for {
		select {

		case event, ok := <-m.watcher.Events:
			if !ok {
				return nil
			}
			m.scheduleProcess(event.Name)

			// If a new directory was created, watch it too (recursive support)
			if event.Op&fsnotify.Create != 0 {
				if info, err := os.Stat(event.Name); err == nil && info.IsDir() {
					m.addWatch(event.Name, true)
				}
			}

		case err, ok := <-m.watcher.Errors:
			if !ok {
				return nil
			}
			fmt.Printf("[setfopd] inotify error: %v\n", err)

		case <-ticker.C:
			fmt.Println("[setfopd] Running periodic full scan...")
			m.fullScan()

		case sig := <-sigCh:
			switch sig {
			case syscall.SIGHUP:
				fmt.Println("[setfopd] SIGHUP received: reloading baseline...")
				bl, err := baseline.Load(m.cfg.BaselinePath)
				if err != nil {
					fmt.Printf("[setfopd] Reload failed: %v\n", err)
				} else {
					m.baseline = bl
					fmt.Println("[setfopd] Baseline reloaded.")
				}
			default:
				fmt.Printf("[setfopd] Signal %v received, shutting down.\n", sig)
				return nil
			}

		case <-m.stopCh:
			return nil
		}
	}
}

// Stop signals the daemon to exit gracefully.
func (m *Monitor) Stop() {
	close(m.stopCh)
}

// registerPaths adds all configured watch paths to the inotify watcher.
func (m *Monitor) registerPaths() error {
	for _, wp := range m.cfg.WatchPaths {
		if err := m.addWatch(wp.Path, wp.Recursive); err != nil {
			fmt.Printf("Warning: could not watch %s: %v\n", wp.Path, err)
		}
	}
	return nil
}

// addWatch adds a single path (and optionally all subdirectories) to the watcher.
func (m *Monitor) addWatch(path string, recursive bool) error {
	if err := m.watcher.Add(path); err != nil {
		return err
	}

	if recursive {
		// Walk subdirectories and add each one individually
		// (fsnotify watches are not recursive by default)
		return filepath.Walk(path, func(p string, info os.FileInfo, err error) error {
			if err != nil {
				return nil
			}
			if info.IsDir() && p != path {
				_ = m.watcher.Add(p)
			}
			return nil
		})
	}

	return nil
}

// scheduleProcess debounces rapid events on the same path.
// The actual diff is run 2 seconds after the last event fires.
func (m *Monitor) scheduleProcess(path string) {
	m.debounceMu.Lock()
	defer m.debounceMu.Unlock()

	if timer, exists := m.debounce[path]; exists {
		timer.Stop()
	}

	m.debounce[path] = time.AfterFunc(2*time.Second, func() {
		m.processPath(path)

		m.debounceMu.Lock()
		delete(m.debounce, path)
		m.debounceMu.Unlock()
	})
}

// processPath diffs a single path against the baseline and logs any changes.
func (m *Monitor) processPath(path string) {
	changes := m.comp.DiffPath(path, m.baseline)
	if len(changes) > 0 {
		m.logger.LogChanges(changes)
	}
}

// fullScan performs a complete baseline diff and logs any changes found.
func (m *Monitor) fullScan() {
	changes, err := m.comp.DiffBaseline()
	if err != nil {
		fmt.Printf("[setfopd] Full scan error: %v\n", err)
		return
	}
	if len(changes) > 0 {
		fmt.Printf("[setfopd] Full scan found %d change(s).\n", len(changes))
		m.logger.LogChanges(changes)
	} else {
		fmt.Println("[setfopd] Full scan: no changes detected.")
	}
}
