package config

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

const (
	DefaultBaselinePath      = "/var/lib/setfop/templates/baseline.yaml"
	DefaultSeverityRulesPath = "/etc/setfop/severity.rules"
	DefaultLogFile           = "/var/log/setfop/drift.log"
	DefaultScanInterval      = 900 // 15 minutes
)

// Load reads all setfop config files and returns a unified Config.
func Load(confPath, pathsConfPath string) (*Config, error) {
	cfg := &Config{
		BaselinePath:      DefaultBaselinePath,
		ScanInterval:      DefaultScanInterval,
		CollectSelinux:    true,
		SeverityRulesPath: DefaultSeverityRulesPath,
		Alert: AlertConfig{
			LogFile:   DefaultLogFile,
			LogLevel:  "INFO",
			SyslogTag: "setfopd",
		},
	}

	// Parse setfop.conf (main daemon config)
	if err := parseMainConf(confPath, cfg); err != nil {
		// Non-fatal: use defaults
		fmt.Printf("Warning: could not parse %s, using defaults: %v\n", confPath, err)
	}

	// Parse paths.conf (monitored paths)
	paths, err := parsePaths(pathsConfPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load paths config: %w", err)
	}
	cfg.WatchPaths = paths

	return cfg, nil
}

// parseMainConf reads a simple INI-style config file.
func parseMainConf(path string, cfg *Config) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()

	var section string
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
			continue
		}

		// Section header e.g. [baseline]
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.ToLower(line[1 : len(line)-1])
			continue
		}

		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.TrimSpace(parts[1])
		// Strip inline comments
		if idx := strings.Index(val, " #"); idx != -1 {
			val = strings.TrimSpace(val[:idx])
		}

		switch section {
		case "baseline":
			switch key {
			case "baseline_path":
				cfg.BaselinePath = val
			case "collect_selinux":
				cfg.CollectSelinux = val == "true"
			case "severity_rules":
				cfg.SeverityRulesPath = val
			}
		case "monitor":
			switch key {
			case "scan_interval":
				if n, err := strconv.Atoi(val); err == nil {
					cfg.ScanInterval = n
				}
			}
		case "alerts":
			switch key {
			case "log_file":
				cfg.Alert.LogFile = val
			case "log_level":
				cfg.Alert.LogLevel = strings.ToUpper(val)
			case "syslog_enable":
				cfg.Alert.SyslogEnable = val == "true"
			case "syslog_facility":
				cfg.Alert.SyslogFacility = val
			case "syslog_tag":
				cfg.Alert.SyslogTag = val
			case "email_enable":
				cfg.Alert.EmailEnable = val == "true"
			case "email_to":
				cfg.Alert.EmailTo = val
			case "email_smtp":
				cfg.Alert.EmailSMTP = val
			case "webhook_enable":
				cfg.Alert.WebhookEnable = val == "true"
			case "webhook_url":
				cfg.Alert.WebhookURL = val
			case "webhook_token":
				// Allow env-var substitution like ${TOKEN}
				cfg.Alert.WebhookToken = os.ExpandEnv(val)
			}
		}
	}

	return scanner.Err()
}

// parsePaths reads paths.conf and returns a slice of WatchPath.
func parsePaths(path string) ([]WatchPath, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("cannot open paths config %s: %w", path, err)
	}
	defer f.Close()

	var paths []WatchPath
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		recursive := strings.HasSuffix(line, "/*")
		cleanPath := strings.TrimSuffix(line, "/*")

		if !strings.HasPrefix(cleanPath, "/") {
			fmt.Printf("Warning: skipping non-absolute path: %s\n", line)
			continue
		}

		paths = append(paths, WatchPath{Path: cleanPath, Recursive: recursive})
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}
	if len(paths) == 0 {
		return nil, fmt.Errorf("no valid paths found in %s", path)
	}

	return paths, nil
}
