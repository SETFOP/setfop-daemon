package alert

import (
	"fmt"
	"log/syslog"
	"os"
	"path/filepath"
	"strings"
	"time"

	"setfop-daemon/pkg/baseline"
	"setfop-daemon/pkg/comparer"
	"setfop-daemon/pkg/config"
)

// Logger writes change alerts to the configured destinations.
type Logger struct {
	cfg  config.AlertConfig
	file *os.File
	sl   *syslog.Writer
}

// NewLogger opens the log file and optional syslog connection.
func NewLogger(cfg config.AlertConfig) (*Logger, error) {
	l := &Logger{cfg: cfg}

	if err := os.MkdirAll(filepath.Dir(cfg.LogFile), 0750); err != nil {
		return nil, fmt.Errorf("cannot create log directory: %w", err)
	}

	f, err := os.OpenFile(cfg.LogFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0640)
	if err != nil {
		return nil, fmt.Errorf("cannot open log file %s: %w", cfg.LogFile, err)
	}
	l.file = f

	if cfg.SyslogEnable {
		facility := parseSyslogFacility(cfg.SyslogFacility)
		sl, err := syslog.New(facility|syslog.LOG_WARNING, cfg.SyslogTag)
		if err != nil {
			fmt.Printf("Warning: could not connect to syslog: %v\n", err)
		} else {
			l.sl = sl
		}
	}

	return l, nil
}

// Close flushes and closes all log destinations.
func (l *Logger) Close() {
	if l.file != nil {
		l.file.Close()
	}
	if l.sl != nil {
		l.sl.Close()
	}
}

// LogChanges writes a batch of changes to all configured outputs.
func (l *Logger) LogChanges(changes []comparer.Change) {
	for _, c := range changes {
		if c.Severity == "IGNORE" {
			continue
		}
		if !SeverityAtLeast(c.Severity, l.cfg.LogLevel) {
			continue
		}
		l.write(c)
	}
}

func (l *Logger) write(c comparer.Change) {
	ts := time.Now().UTC().Format(time.RFC3339)
	action := strings.ToUpper(string(c.Type))

	var sb strings.Builder
	fmt.Fprintf(&sb, "%s [%s] %s: %s\n", ts, c.Severity, action, c.Path)

	if c.Old != nil && c.New != nil {
		for _, field := range c.DiffFields {
			oldVal := entryField(c.Old, field)
			newVal := entryField(c.New, field)
			fmt.Fprintf(&sb, "  - %s: %s -> %s\n", field, oldVal, newVal)
		}
	} else if c.Type == ChangeAdded && c.New != nil {
		fmt.Fprintf(&sb, "  + new file: mode=%s uid=%d gid=%d size=%d\n",
			c.New.Mode, c.New.UID, c.New.GID, c.New.Size)
	} else if c.Type == ChangeDeleted && c.Old != nil {
		fmt.Fprintf(&sb, "  - deleted: was mode=%s uid=%d size=%d\n",
			c.Old.Mode, c.Old.UID, c.Old.Size)
	}

	if c.RuleName != "" {
		fmt.Fprintf(&sb, "  Rule matched: %q -> severity=%s\n", c.RuleName, c.Severity)
	}
	sb.WriteString("\n")

	msg := sb.String()

	if l.file != nil {
		l.file.WriteString(msg)
	}
	fmt.Print(msg)

	if l.sl != nil {
		switch c.Severity {
		case "CRITICAL":
			l.sl.Crit(strings.TrimSpace(msg))
		case "HIGH":
			l.sl.Err(strings.TrimSpace(msg))
		case "MEDIUM":
			l.sl.Warning(strings.TrimSpace(msg))
		default:
			l.sl.Info(strings.TrimSpace(msg))
		}
	}
}

func entryField(e *baseline.FileEntry, field string) string {
	switch field {
	case "inode":
		return fmt.Sprintf("%d", e.Inode)
	case "mode":
		return e.Mode
	case "uid":
		return fmt.Sprintf("%d", e.UID)
	case "gid":
		return fmt.Sprintf("%d", e.GID)
	case "size":
		return fmt.Sprintf("%d", e.Size)
	case "mod_time":
		return e.ModTime
	case "selinux_context":
		return e.SelinuxCtx
	default:
		return "?"
	}
}

func parseSyslogFacility(s string) syslog.Priority {
	switch strings.ToUpper(s) {
	case "LOCAL0":
		return syslog.LOG_LOCAL0
	case "LOCAL1":
		return syslog.LOG_LOCAL1
	case "LOCAL2":
		return syslog.LOG_LOCAL2
	case "LOCAL3":
		return syslog.LOG_LOCAL3
	case "LOCAL4":
		return syslog.LOG_LOCAL4
	case "LOCAL5":
		return syslog.LOG_LOCAL5
	case "LOCAL6":
		return syslog.LOG_LOCAL6
	case "LOCAL7":
		return syslog.LOG_LOCAL7
	case "DAEMON":
		return syslog.LOG_DAEMON
	case "AUTH":
		return syslog.LOG_AUTH
	default:
		return syslog.LOG_LOCAL0
	}
}
